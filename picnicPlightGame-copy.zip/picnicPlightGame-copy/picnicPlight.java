import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class picnicPlight extends World
{

    public Score score = new Score();
    
    public EnemyScore enemyScore = new EnemyScore();
    
    public picnicPlight()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        userPlayer boy = new userPlayer();
        addObject(boy,42,191);
        antOne antOne = new antOne();
        addObject(antOne,540,57);
        antThree antThree = new antThree();
        addObject(antThree,549,354);
        antTwo antTwo = new antTwo();
        addObject(antTwo,540,205);
        antThree.setLocation(538,347);
        cupcake cupcake = new cupcake();
        addObject(cupcake,290,187);
        foodEight foodEight = new foodEight();
        addObject(foodEight,374,43);
        foodEleven foodEleven = new foodEleven();
        addObject(foodEleven,422,263);
        foodFive foodFive = new foodFive();
        addObject(foodFive,158,78);
        foodFour foodFour = new foodFour();
        addObject(foodFour,436,126);
        foodFourteen foodFourteen = new foodFourteen();
        addObject(foodFourteen,306,303);
        foodNine foodNine = new foodNine();
        addObject(foodNine,408,338);
        foodOne foodOne = new foodOne();
        addObject(foodOne,59,73);
        foodSeven foodSeven = new foodSeven();
        addObject(foodSeven,73,331);
        foodSix foodSix = new foodSix();
        addObject(foodSix,155,237);
        foodTen foodTen = new foodTen();
        addObject(foodTen,278,99);
        foodThirteen foodThirteen = new foodThirteen();
        addObject(foodThirteen,208,353);
        foodThree foodThree = new foodThree();
        addObject(foodThree,537,269);
        foodTwelve foodTwelve = new foodTwelve();
        addObject(foodTwelve,388,187);
        foodSix.setLocation(180,274);
        foodFourteen.setLocation(140,180);
        foodOne.setLocation(61,41);
        foodFive.setLocation(118,105);
        foodTen.setLocation(206,47);
        foodTwelve.setLocation(304,96);
        foodThirteen.setLocation(291,365);
        foodEleven.setLocation(424,220);
        foodFour.setLocation(475,115);
        foodEleven.setLocation(392,183);
        foodTwo foodTwo = new foodTwo();
        addObject(foodTwo,411,243);
        foodSix.setLocation(246,277);
        foodFourteen.setLocation(126,179);
        foodFourteen.setLocation(148,252);
        foodFive.setLocation(187,160);
        foodOne.setLocation(104,95);
        foodTen.setLocation(176,40);
        foodTwelve.setLocation(276,91);
        foodFour.setLocation(430,109);
        foodEleven.setLocation(413,179);
        foodFour.setLocation(469,129);
        foodThree.setLocation(357,99);
        foodEight.setLocation(425,62);
        foodThree.setLocation(371,107);
        foodTwelve.setLocation(275,68);
        foodFive.setLocation(184,143);
        foodFourteen.setLocation(144,233);
        foodSeven.setLocation(142,330);
        foodSeven.setLocation(137,341);
        foodFourteen.setLocation(134,243);
        foodNine.setLocation(413,328);
        addObject(score, 80, 30);
        addObject(enemyScore, 500, 30);
    }
}
