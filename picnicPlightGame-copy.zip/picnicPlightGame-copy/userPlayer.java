import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class boy here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class userPlayer extends Actor
{
    cupcake cupcake = new cupcake();
    
    public void act()
    {
        if (Greenfoot.isKeyDown("Right")) {
            setRotation(0);
            move(2);
        }
        if (Greenfoot.isKeyDown("Down")) {
            setRotation(90);
            move(2);
        }
        if (Greenfoot.isKeyDown("Left")) {
            setRotation(180);
            move(2);
        }
        if (Greenfoot.isKeyDown("Up")) {
            setRotation(270);
            move(2);
        }
        //FOOD SCORES
        if (isTouching(cupcake.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(3);
            removeTouching(cupcake.class);
        }
        if (isTouching(foodOne.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodOne.class);
        }
        if (isTouching(foodTwo.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodTwo.class);
        }
        if (isTouching(foodThree.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodThree.class);
        }
        if (isTouching(foodFour.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodFour.class);
        }
        if (isTouching(foodFive.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodFive.class);
        }
        if (isTouching(foodSix.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodSix.class);
        }
        if (isTouching(foodSeven.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodSeven.class);
        }
        if (isTouching(foodEight.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodEight.class);
        }
        if (isTouching(foodNine.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodNine.class);
        }
        if (isTouching(foodTen.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodTen.class);
        }
        if (isTouching(foodEleven.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodEleven.class);
        }
        if (isTouching(foodTwelve.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodTwelve.class);
        }
        if (isTouching(foodThirteen.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodThirteen.class);
        }
        if (isTouching(foodFourteen.class)) {
            Score bObject = (Score) getWorld().getObjects(Score.class).get(0);
            bObject.addScore(1);
            removeTouching(foodFourteen.class);
        }
    }
}
