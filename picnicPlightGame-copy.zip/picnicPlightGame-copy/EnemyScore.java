import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class EnemyScore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EnemyScore extends Actor
{
    private int enemyScore = 0;
    
    public EnemyScore() {
        updateImage();
    }
    
    public void addEnemyScore(int points) {
        enemyScore += points;
        updateImage();
    }
    
    public void act()
    {
        // Add your action code here.
    }
    
    private void updateImage() {
        setImage(new GreenfootImage("Enemy Score = " + enemyScore, 24, Color.BLACK, new Color(0,0,0,0)));
    }
}
