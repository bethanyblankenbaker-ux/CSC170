import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class antTwo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class antTwo extends Actor
{
    /**
     * Act - do whatever the antTwo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        turn(Greenfoot.getRandomNumber(90) - 45);
        move(5);
        if (isTouching(cupcake.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(3);
            removeTouching(cupcake.class);
        }
        if (isTouching(foodOne.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodOne.class);
        }
        if (isTouching(foodTwo.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodTwo.class);
        }
        if (isTouching(foodThree.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodThree.class);
        }
        if (isTouching(foodFour.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodFour.class);
        }
        if (isTouching(foodFive.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodFive.class);
        }
        if (isTouching(foodSix.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodSix.class);
        }
        if (isTouching(foodSeven.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodSeven.class);
        }
        if (isTouching(foodEight.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodEight.class);
        }
        if (isTouching(foodNine.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodNine.class);
        }
        if (isTouching(foodTen.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodTen.class);
        }
        if (isTouching(foodEleven.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodEleven.class);
        }
        if (isTouching(foodTwelve.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodTwelve.class);
        }
        if (isTouching(foodThirteen.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodThirteen.class);
        }
        if (isTouching(foodFourteen.class)) {
            EnemyScore bObject = (EnemyScore) getWorld().getObjects(EnemyScore.class).get(0);
            bObject.addEnemyScore(1);
            removeTouching(foodFourteen.class);
        }
    }
}
